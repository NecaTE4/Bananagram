class Usermodel {
  final String email;
  final String profileImageUrl;
  final String username;

  Usermodel(this.email, this.profileImageUrl, this.username);
}
